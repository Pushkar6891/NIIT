import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component3',
  templateUrl: './component3.component.html',
  styleUrls: ['./component3.component.css']
})
export class Component3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = 'component-communication';
  name: string = "Invinsible"; // Declaring a variable in parent and using it in component
  
  /* Only one String :  static*/
  // stdName: string; // Using Dynamic Values generating by Parent and child will use it to display
  
  /* Multiple Names :  dynamic*/
  //stdName: Array<string> = new Array();
  stdName:string;
  
  addNames(stdName: string) {
     this.stdName = stdName;
    //this.stdName.push(stdName);
  }

}
