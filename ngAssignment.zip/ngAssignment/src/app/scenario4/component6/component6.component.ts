import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';




@Component({
  selector: 'app-component6',
  templateUrl: './component6.component.html',
  styleUrls: ['./component6.component.css']
})
export class Component6Component implements OnInit {

  @Output()
  outputToParent = new EventEmitter<string>();

  messageInChild: string = "";

  constructor() { }

  ngOnInit() {
  }

  addNames(stdName: string) {
    this.messageInChild = stdName;
    this.outputToParent.emit(stdName);
  }

}
