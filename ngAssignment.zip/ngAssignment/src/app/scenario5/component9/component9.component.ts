import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-component9',
  templateUrl: './component9.component.html',
  styleUrls: ['./component9.component.css']
})
export class Component9Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Output()
  outputToParent = new EventEmitter<string>();

  messageInChild: string = "";
  
  addNames(stdName: string) {
    this.messageInChild = stdName;
    this.outputToParent.emit(stdName);
  }

}


