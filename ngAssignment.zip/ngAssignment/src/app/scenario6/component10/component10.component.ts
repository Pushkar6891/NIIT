import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component10',
  templateUrl: './component10.component.html',
  styleUrls: ['./component10.component.css']
})
export class Component10Component implements OnInit {


  constructor() { }

  ngOnInit() {
  }

  title = 'component-communication';
  name: string = "Invinsible";
  
  stdName:string;
  
  addNames(stdName: string) {
     this.stdName = stdName;
  }

}
