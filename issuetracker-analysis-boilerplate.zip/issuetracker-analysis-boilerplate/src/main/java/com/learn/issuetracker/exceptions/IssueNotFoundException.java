package com.learn.issuetracker.exceptions;

@SuppressWarnings("serial")
public class IssueNotFoundException extends RuntimeException {
	public IssueNotFoundException() {
		super();
	}
}
