package com.learn.issuetracker.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import com.learn.issuetracker.exceptions.IssueNotFoundException;
import com.learn.issuetracker.model.Employee;
import com.learn.issuetracker.model.Issue;
import com.learn.issuetracker.repository.IssueRepository;

/*
 * This class contains functionalities for searching and analyzing Issues data Which is stored in a collection
 * Use JAVA8 STREAMS API to do the analysis
 * 
*/
public class IssueTrackerServiceImpl implements IssueTrackerService {

	/*
	 * CURRENT_DATE contains the date which is considered as todays date for this
	 * application Any logic which uses current date in this application, should
	 * consider this date as current date
	 */
	private static final String CURRENT_DATE = "2019-05-01";

	/*
	 * The issueDao should be used to get the List of Issues, populated from the
	 * file
	 */
	private IssueRepository issueDao;
	private LocalDate today;

	/*
	 * Initialize the member variables Variable today should be initialized with the
	 * value in CURRENT_DATE variable
	 */
	public IssueTrackerServiceImpl(IssueRepository issueDao) {
		LocalDate date = LocalDate.parse(CURRENT_DATE);
		this.today = date;
		this.issueDao = issueDao;
	}

	/*
	 * In all the below methods, the list of issues should be obtained by used
	 * appropriate getter method of issueDao.
	 */
	/*
	 * The below method should return the count of issues which are closed.
	 */
	@Override
	public long getClosedIssueCount() {
		long total = 0;
		List<Issue> issues = issueDao.getIssues();
		for (Issue issue : issues) {
			if (issue.getStatus().equals("CLOSED"))
				total = total + 1;
		}
		return total;
	}

	/*
	 * The below method should return the Issue details given a issueId. If the
	 * issue is not found, method should throw IssueNotFoundException
	 */

	@Override
	public Issue getIssueById(String issueId) throws IssueNotFoundException {
		List<Issue> issues = issueDao.getIssues();
		for (Issue issue : issues) {
			if (issue.getIssueId().equals(issueId))
				return issue;
		}
		throw new IssueNotFoundException();
	}

	/*
	 * The below method should return the Employee Assigned to the issue given a
	 * issueId. It should return the employee in an Optional. If the issue is not
	 * assigned to any employee or the issue Id is incorrect the method should
	 * return empty optional
	 */
	@Override
	public Optional<Employee> getIssueAssignedTo(String issueId) {
		List<Issue> issues = issueDao.getIssues();
		Employee employee = null;
		for (Issue issue : issues) {
			if (issue.getIssueId().equals(issueId))
				employee = issue.getAssignedTo();
		}

		return Optional.of(employee);
	}

	/*
	 * The below method should return the list of Issues given the status. The
	 * status can contain values OPEN / CLOSED
	 */
	@Override
	public List<Issue> getIssuesByStatus(String status) {
		List<Issue> issues = issueDao.getIssues();
		List<Issue> issuesByStatus = new ArrayList<Issue>();
		for (Issue issue : issues) {
			if (issue.getStatus().equals(status))
				issuesByStatus.add(issue);
		}
		return issuesByStatus;
	}

	/*
	 * The below method should return a LinkedHashSet containing issueid's of open
	 * issues in the ascending order of expected resolution date
	 */
	@Override
	public Set<String> getOpenIssuesInExpectedResolutionOrder() {
		List<Issue> issues = issueDao.getIssues();
		Set<String> sorted = issues.stream().filter(i -> i.getStatus().equals("OPEN"))
				.sorted(Comparator.comparing(Issue::getExpectedResolutionOn)).map(i -> i.getIssueId())
				.collect(Collectors.toCollection(LinkedHashSet::new));
		return sorted;
	}

	/*
	 * The below method should return a List of open Issues in the descending order
	 * of Priority and ascending order of expected resolution date within a priority
	 */
	@Override
	public List<Issue> getOpenIssuesOrderedByPriorityAndResolutionDate() {
		List<Issue> issues = issueDao.getIssues();
		List<Issue> prioriryHigh = issues
				.stream().filter(issue -> issue.getStatus().equals("OPEN")).sorted(Comparator
						.comparing(Issue::getPriority).reversed().thenComparing(Issue::getExpectedResolutionOn))
				.collect(Collectors.toList());
		return prioriryHigh;
	}

	/*
	 * The below method should return a List of 'unique' employee names who have
	 * issues not closed even after 7 days of Expected Resolution date. Consider the
	 * current date as 2019-05-01
	 */
	@Override
	public List<String> getOpenIssuesDelayedbyEmployees() {
		List<Issue> issues = issueDao.getIssues();
		return issues.stream()
				.filter(i -> ChronoUnit.DAYS.between(i.getExpectedResolutionOn(), LocalDate.parse(CURRENT_DATE)) > 7
						&& i.getStatus().equals("OPEN"))
				.map(i -> i.getAssignedTo().getName()).collect(Collectors.toList());
	}

	/*
	 * The below method should return a map with key as issueId and value as
	 * assigned employee Id. THe Map should contain details of open issues having
	 * HIGH priority
	 */
	@Override
	public Map<String, Integer> getHighPriorityOpenIssueAssignedTo() {
		Map<String, Integer> map = new HashMap<>();
		for (Issue issue : issueDao.getIssues()) {
			if (issue.getPriority().equals("HIGH") && issue.getStatus().equals("OPEN")) {
				map.put(issue.getIssueId(), issue.getAssignedTo().getEmplId());
			}
		}
		;
		return map;
	}

	/*
	 * The below method should return open issues grouped by priority in a map. The
	 * map should have key as issue priority and value as list of open Issues
	 */
	@Override
	public Map<String, List<Issue>> getOpenIssuesGroupedbyPriority() {
		Map<String, List<Issue>> result = issueDao.getIssues().stream()
				.filter(issue -> issue.getStatus().equals("OPEN"))
				.collect(Collectors.groupingBy(Issue::getPriority, Collectors.toList()));
		return result;
	}

	/*
	 * The below method should return count of open issues grouped by priority in a
	 * map. The map should have key as issue priority and value as count of open
	 * issues
	 */
	@Override
	public Map<String, Long> getOpenIssuesCountGroupedbyPriority() {
		Map<String, Long> result = issueDao.getIssues().stream().filter(issue -> issue.getStatus().equals("OPEN"))
				.collect(Collectors.groupingBy(Issue::getPriority, Collectors.counting()));
		return result;
	}

	/*
	 * The below method should provide List of issue id's(open), grouped by location
	 * of the assigned employee. It should return a map with key as location and
	 * value as List of issue Id's of open issues
	 */
	@Override
	public Map<String, List<String>> getOpenIssueIdGroupedbyLocation() {
		Map<String, List<Issue>> result = issueDao.getIssues().stream()
				.filter(issue -> issue.getStatus().equals("OPEN"))
				.collect(Collectors.groupingBy(issue -> issue.getAssignedTo().getLocation(), Collectors.toList()));
		Map<String, List<String>> resultFinal = new HashMap<>();
		for (Entry<String, List<Issue>> entry : result.entrySet()) {
			resultFinal.put(entry.getKey(),
					entry.getValue().stream().map(i -> i.getIssueId()).collect(Collectors.toList()));
		}
		return resultFinal;
	}

	/*
	 * The below method should provide the number of days, since the issue has been
	 * created, for all high/medium priority open issues. It should return a map
	 * with issueId as key and number of days as value. Consider the current date as
	 * 2019-05-01
	 */
	@Override
	public Map<String, Long> getHighMediumOpenIssueDuration() {
		Map<String, Long> map = issueDao.getIssues().stream()
				.filter(issue -> (issue.getPriority().equals("HIGH") || issue.getPriority().equals("MEDIUM"))
						&& issue.getStatus().equals("OPEN"))
				.collect(Collectors.toMap(Issue::getIssueId,
						issue -> ChronoUnit.DAYS.between(issue.getCreatedOn(), LocalDate.parse(CURRENT_DATE))));
		return map;
	}
}