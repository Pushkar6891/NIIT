var x = 5;

function check() {
    y = 10;
    console.log(x);
    var x = 10;
}

function check2() {
    console.log(y);
}
check();
check2();