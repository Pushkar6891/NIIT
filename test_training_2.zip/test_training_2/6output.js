function sum(x) {
    var s = 0;
    for (var i = 0; i < arguments.length; i++) {
        s += arguments[i];
    }
    //  return s;
    console.log(s);
}
sum(3, 4, 5);