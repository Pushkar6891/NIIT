var z = { first: true };

function g(a) {
    a = { first: true };
    console.log(a);
}

g(z);
console.log(z);