function f(a, b, c) {
    m = ["1", "2", "3"];
    a = 3;
    b[0] = "X";
    c.first = false;
}
var x = 4;
var y = ["A", "B", "C"];
var z = { first: true };
f(x, y, z);
console.log(x, y, z);

function g(a) {
    a = { first: true };
    console.log(a);
}

g(z);
console.log(z);