function average(a, b) {
    // return (0.11 + 0.2) == 0.3;
    // return 0.1 + 0.2 != 0.3;
    // return .1 + .2 != .3;
    return 0.1 + 0.3;
}
console.log(average(2, 1));