var arrayList = ['a', 'b', 'c', 'd', 'e', 'f'];
// console.log(typeof arrayList); // object
// console.log(typeof arguments); // undefined
console.log(2 + true);
console.log(true + 2);
console.log(true + false);
console.log(false + 2);
console.log('6' + 9); // undefined
console.log(4 + 3 + 2 + "1");
console.log("1" + 2 + 4);
console.log(-'34' + 10);
console.log(-'34' + 10);
var y = 1,
    x = y = typeof x;
var a = (2, 3, 5); 
var a = (1, 5 - 1) * 2;
console.log(!'bang');
console.log(parseFloat('12.3.4'));
console.log(Math.max([2, 3, 4, 5]));
console.log(3 instanceof Number);
console.log(null == undefined);
console.log(!! function() {});
console.log(typeof bar);
console.log(typeof null);
var a = 2;
var b = 3;
console.log(a && b);
var foo = 'outside';

function logIt() { console.log(foo); var foo = 'inside'; }
logIt();
console.log(-5 % 2);
console.log(.1 + .2 != .3);
console.log(42..toString());
//console.log(4.2..toString);
//console.log(42. toString());
console.log(typeof(NaN));
console.log(2 in [1, 2]);