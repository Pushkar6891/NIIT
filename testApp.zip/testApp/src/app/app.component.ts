import { Component } from '@angular/core';
import { SearchService } from './search.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'testApp';

  searchData: string;

  constructor(private service: SearchService) {

  }

  public onSubmit(data) {
    // this.firstName = data.firstName;
    // console.log(this.firstName);
    // console.log(data);
    this.searchData = data.searchData;
    console.log("Component Called:  " + this.searchData);

    this.service.getData(data.searchData).subscribe(
      response => {
        console.log(response);
      },
      error => {
        console.log(error)
      });
  }
}
