export class RepositoryConfig {
    
      total_count: number;
      incomplete_results: boolean;
      items_id: number;
      items_name:string;
      items_html_url:string;
    
}
  
  