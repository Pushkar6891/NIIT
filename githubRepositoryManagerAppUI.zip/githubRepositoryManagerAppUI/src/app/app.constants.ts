export const API_URL = "http://localhost:8080"
export const ALL_GIT_REPOS_URL = "https://api.github.com/search/repositories?q=stars%3A>1&s=stars&type=Repositories&sort=desc";
export const AUTHENTICATION_TOKEN = "token 8e6a9d803b3cfe1d8f60c4c30a336e81e9a2c24d";
