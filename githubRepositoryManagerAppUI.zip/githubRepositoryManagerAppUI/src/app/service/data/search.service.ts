import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ALL_GIT_REPOS_URL } from 'src/app/app.constants';

//export const TOKEN = "AUTHENTICATION_TOKEN";

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  constructor(private http: HttpClient) { }

  retrieveRepos(): Observable<any> {

    // let headers = new HttpHeaders({
    //   'Authorization': TOKEN,
    //   'Access-Control-Allow-Origin': '*'
    // });

  //return this.http.get(`${ALL_GIT_REPOS_URL}`,{ headers });
  return this.http.get(`${ALL_GIT_REPOS_URL}`);
  }

}
