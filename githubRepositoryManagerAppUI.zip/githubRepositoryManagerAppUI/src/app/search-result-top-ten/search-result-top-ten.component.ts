import { Component, OnInit } from '@angular/core';
import { SearchService } from '../service/data/search.service';
import { RepositoryConfig } from '../model/RepositoryConfig';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-search-result-top-ten',
  templateUrl: './search-result-top-ten.component.html',
  styleUrls: ['./search-result-top-ten.component.css']
})
export class SearchResultTopTenComponent implements OnInit {
  total_count:number;
  incomplete_results:boolean;
  items;
  owner;

  startIndex = 0;
  endIndex = 10;

  configurations: Array<any> = [];

  constructor(private service: SearchService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
  //  this.refreshRepos();
  }

  refreshRepos() {
    this.service.retrieveRepos().subscribe(data => {
      console.log(data);
    // this.configurations = data;

    
    for(var i=0;i<data.items.length;i++){
 //     for(var i=0;i<10;i++){
//    let config = new RepositoryConfig(data);
      let config = new RepositoryConfig();
      config.total_count = data.total_count;
      config.incomplete_results= data.incomplete_results;
      config.items_id = data.items[i].id;
      config.items_name = data.items[i].name;
      config.items_html_url = data.items[i].html_url;
      this.configurations.push(config);
      // this.total_count = 0;
      // this.incomplete_results = false;
    }
      

    }, error => {
      console.log(error);
    });
  }

  getArrayFromNumber(length){
    return new Array(length).map((a,i)=>{
      return i;
    });
  }

  updateIndex(pageIndex){
    this.startIndex = pageIndex * 10;
    this.endIndex = this.startIndex + 10;
  }

}
