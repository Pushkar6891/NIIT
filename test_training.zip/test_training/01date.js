// Format mm/dd/yyyy
var date = new Date();
document.writeln((date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear());