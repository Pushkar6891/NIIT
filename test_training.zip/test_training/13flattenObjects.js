// var arr = [5, [22],
//     [
//         [14]
//     ],
//     [
//         [4]
//     ],
//     [5, 6]
// ]
// var flatenned = arr.reduce(function(a, b) { return a.concat(b) }, []);
// //var temp = [];

// //var temp = flatenned.toString().split(',');
// var temp = JSON.stringify(flatenned);
// //JSON.stringify(temp);
// //temp.push(flatenned);
// var temp2 = JSON.stringify(temp);
// document.writeln(flatenned);
// document.writeln("<br/>");
// document.writeln(temp);
// document.writeln("<br/>");
// document.writeln(temp2);
// document.writeln("<br/>");

var arr = [5, [22],
    [
        [14]
    ],
    [
        [4]
    ],
    [5, 6]
];

//var arr = [1, 2, [3, 4, [5, 6]]];

// to enable deep level flatten use recursion with reduce and concat
function flatDeep(arr, d = 1) {
    return d > 0 ? arr.reduce((acc, val) => acc.concat(Array.isArray(val) ? flatDeep(val, d - 1) : val), []) :
        arr.slice();
};



document.writeln("[" + flatDeep(arr, Infinity) + "]");