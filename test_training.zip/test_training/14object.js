var myObj = [
    { 'name': 'Saurabh', 'age': 30, 'occupation': "Team Leader" },
    { 'name': 'Anupriya', 'age': 32, 'occupation': "Team Leader" },
    { 'name': 'Kalyani', 'age': 25, 'occupation': "Programmer" },
    { 'name': 'Damodaran', 'age': 27, 'occupation': "Programmer" },
    { 'name': 'Krishnakath', 'age': 22, 'occupation': "Programmer" },
    { 'name': 'Venketraman', 'age': 28, 'occupation': "Programmer" }
];

// 1. Find objects who are programmer
document.writeln("1. Find objects who are programmer");
for (var i = 0; i < myObj.length; i++) {
    if (myObj[i].occupation == "Programmer")
        document.writeln(myObj[i].name + " " + myObj[i].age + " " + myObj[i].occupation);

    document.writeln("<br/>");
}

document.writeln("<br/>");

// 2. Sort objects by age
document.writeln("2. Sort objects by age");
myObj.sort((a, b) => (a.age > b.age) ? -1 : 1);

for (var i = 0; i < myObj.length; i++) {
    document.writeln(myObj[i].name + " " + myObj[i].age + " " + myObj[i].occupation);

    document.writeln("<br/>");
}

// 3. Recreate the above array of objects into the following object of objects :
// { 'Team Leader' : [{'name':_____________, 'age':__________},{}],
// '<anotheroccupation>': [{'name':______________, 'age':________},{}]}
document.writeln("<br/>");


let myOrderedArray = myObj.reduce(function(accumulator, currentValue) {
    if (accumulator[currentValue.occupation]) {
        accumulator[currentValue.occupation].push({ "name": currentValue.name, "age": currentValue.age });
    } else {
        accumulator[currentValue.occupation] = [{ "name": currentValue.name, "age": currentValue.age }];
    }
    return accumulator;
}, {});

document.writeln(JSON.stringify(myOrderedArray));

document.writeln("<br/>");

// 4.Use the map function to create a new array containing only names present in myObj.
// ['Saurabh',
//     'Anupriya',
//     'Kalyani',
//     'Damodaran',
//     'Krishnakath',
//     'Venketraman'
// ]

//console.log(object.keys(myObj));

var myObj2 = [
    { 'name': 'Saurabh', 'age': 30, 'occupation': "Team Leader" },
    { 'name': 'Anupriya', 'age': 32, 'occupation': "Team Leader" },
    { 'name': 'Kalyani', 'age': 25, 'occupation': "Programmer" },
    { 'name': 'Damodaran', 'age': 27, 'occupation': "Programmer" },
    { 'name': 'Krishnakath', 'age': 22, 'occupation': "Programmer" },
    { 'name': 'Venketraman', 'age': 28, 'occupation': "Programmer" }
];

function getName(item) {
    var myName = [item.name].join(" ");
    return myName;
}

function myFunction() {
    document.getElementById("demo").innerHTML = myObj2.map(getName);
}