var num = [80, 30, 40, 90, 70];
var max = num[0];
for (var i = 1; i < num.length; i++) {

    if (num[i] > max) {
        max = num[i];
        break;
    }

}
document.writeln("Max number is : ");
document.writeln(max);