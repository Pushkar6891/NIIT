var colors = ["red", "green", "blue", "red", "green"];
document.writeln("Original :");
document.writeln(colors);
document.writeln("<br/>");

// 1. First Way
var uniqueColors = [...new Set(colors)];
document.writeln("Way 1 :");
document.writeln(uniqueColors);
document.writeln("<br/>");

// // 2. Second Way
document.writeln("Way 2 :");
document.writeln(Array.from(new Set(colors)));

// 3. Third Way
var myUniqueColors = [];
for (var i = 0; i < colors.length; i++) {
    if (myUniqueColors.indexOf(colors[i]) == -1) {
        myUniqueColors.push(colors[i]);
    }
}

document.writeln("<br/>");
document.writeln("Way 3 :");
document.writeln(myUniqueColors);

// 3. Find Duplicates in Array
// var myUniqueColors = [];
// var j = 1;
// document.writeln(myUniqueColors);
// document.writeln("<br/>");
// document.writeln("<br/>");

// for (var i = 0; i < colors.length; i++) {
//     for (var j = i + 1; j < colors.length; j++) {
//         if (colors[i] == colors[j]) {
//             myUniqueColors[i] = colors[i];
//         }
//     }
// }
// document.writeln(myUniqueColors);