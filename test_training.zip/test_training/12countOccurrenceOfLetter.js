function countOccurrenceOfLetter(myInputWord, myInputLetter) {
    //   var myInputWord = document.getElementById('myInputWord').value;
    //   var myInputLetter = document.getElementById('myInputLetter').value;
    var result = 0;
    for (var i = 0; i < myInputWord.length; i++) {
        if (myInputWord[i] == myInputLetter) {
            result++;
        }
    }
    document.writeln(result);
    // document.writeln(result + " " + myInputWord + " " + myInputLetter);
    // return result;

}