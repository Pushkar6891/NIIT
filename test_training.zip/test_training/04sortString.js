var cities = ["Mumbai", "Goa", "Chennai", "Delhi"];
cities.sort();
document.writeln("Asc");
document.write("<br/>");
document.writeln(cities);
cities.reverse();
document.write("<br/>");
document.writeln("Desc");
document.writeln(cities);