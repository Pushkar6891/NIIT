var arr1 = [9, 8, 2, 6, 3, 9];
var arr2 = [9, 6, 4, 6, 5, 2, 9];

for (var i = 0; i < arr1.length; i++) {

    if (i > arr2.length - 1) {
        document.writeln(Math.abs(arr1[i]));
    } else {
        document.writeln(Math.abs(arr1[i] - arr2[i]));
    }
}
if (arr2.length > arr1.length) {
    for (var i = arr1.length; i < arr2.length; i++) {
        document.writeln(Math.abs(arr2[i]));
    }
}