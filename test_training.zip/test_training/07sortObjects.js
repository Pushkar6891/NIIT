var library = [
    { author: 'Bill Gates', title: 'The Road Ahead', libraryID: 1254 },
    { author: 'Steve Jobs', title: 'Walter Isaacson', libraryID: 4264 },
    { author: 'Suzanne Collins', title: 'Mockingjay: The Final Book of The Hunger Games', libraryID: 3245 }
];

document.writeln("Unsorted : ");
document.writeln("<br/>");
for (var i = 0; i < 3; i++) {
    document.writeln(library[i].title);
    document.writeln("<br/>");
}

document.writeln("<br/>");

library.sort((a, b) => (a.title > b.title) ? 1 : -1);

console.log(library);

document.writeln("Ascending Order Sorted : ");
document.writeln("<br/>");
for (var i = 0; i < 3; i++) {
    document.writeln(library[i].title);
    document.writeln("<br/>");
}

document.writeln("<br/>");
library.sort((a, b) => (a.title > b.title) ? -1 : 1);
document.writeln("Descending Order Sorted : ");
document.writeln("<br/>");
for (var i = 0; i < 3; i++) {
    document.writeln(library[i].title);
    document.writeln("<br/>");
}



//    document.getElementById("lib").innerHTML = library[i].title;

//document.writeln(JSON.parse(JSON.stringify(library)));