var student = {
    name: "David Rayy",
    sclass: "VI",
    rollno: 12
};
var studentKeys = Object.keys(student);
//document.writeln(student.name + "," + student.sclass + "," + student.rollno);
//document.writeln(studentKeys[0] + "," + studentKeys[1] + "," + studentKeys[2]);
document.writeln(studentKeys);
//document.writeln(studentKeys.reverse());