var students = [
    { studentName: 'David', marks: 80, grade: null },
    { studentName: 'Vinoth', marks: 77, grade: null },
    { studentName: 'Divya', marks: 88, grade: null },
    { studentName: 'Ishitha', marks: 95, grade: null },
    { studentName: 'Thomas', marks: 68, grade: null }
];

var total = 0;
var studentsCount = students.length;
for (var i = 0; i < students.length; i++) {
    total += students[i].marks;
}

//document.writeln(total);
//document.writeln("<br/>");
var averageMarks = total / studentsCount;
document.writeln("Average : " + averageMarks);

for (var i = 0; i < students.length; i++) {
    var studentMarks = students[i].marks;
    if (studentMarks < 60) {
        students[i].grade = 'F';
    } else if (studentMarks > 60 && studentMarks <= 70) {
        students[i].grade = 'D';
    } else if (studentMarks > 70 && studentMarks <= 80) {
        students[i].grade = 'C';
    } else if (studentMarks > 80 && studentMarks <= 90) {
        students[i].grade = 'B';
    } else if (studentMarks > 90 && studentMarks <= 100) {
        students[i].grade = 'A';
    }
}
document.writeln("<br/>");
for (var i = 0; i < students.length; i++) {
    document.writeln(students[i].studentName + " " + students[i].marks + " " + students[i].grade);
    document.writeln("<br/>");
}