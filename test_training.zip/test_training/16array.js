var obj = {
    "One": "1",
    "Two": "2",
    "Three": "3",
    "Four": "4"
}

//var arr = ;

document.writeln(JSON.stringify(Object.values(obj)));