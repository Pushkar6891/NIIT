var jsonStr = '{"mike":"Book","jason":"sweater","chels":"iPad"}';
var obj = JSON.parse(jsonStr);
//document.writeln(obj.mike);
//document.writeln(obj.jason);
//document.writeln(obj.chels);

for (let x in obj) {
    if (x === "jason")
        document.writeln(x + " : " + obj[x]);
}

//document.writeln(Object.values(jsonStr));
document.writeln("<br/>");
//var myObj = JSON.stringify(obj);
//document.writeln(myObj.toString().);
// for (var key in myObj) {
//     //   document.writeln(" Key : " + key);
//     document.writeln(myObj[key]);
// }
//document.writeln(obj);
//console.log(obj);

// var myMap = new Map();
// //myMap[newKey] = newValue;

// myMap["mike"] = "Book";
// myMap["jason"] = "sweater";
// myMap["chels"] = "iPad";

// for (let key of myMap.keys()) {
//     console.log('key:' + key);
// }

// for (let value of myMap.values()) {
//     console.log('value:' + value);
// }