function test() {
    var num = document.getElementById("num").value;
    var temp = "";
    //  var digits = N.toString().split('').map(Number);
    for (var i = 0; i < num.toString().length; i++) {
        temp += num.charAt(i);
        if (num.charAt(i) % 2 == 0 && num.charAt(i + 1) % 2 == 0 && i != num.toString().length - 1) {
            // document.writeln(num.charAt(i));
            temp += "-";
        }

    }
    document.write(temp);
    //document.write(num);
}