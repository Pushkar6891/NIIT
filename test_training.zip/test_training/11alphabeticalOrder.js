function sortAlphabatically() {
    var myInput = document.getElementById('myInput').value;
    var myOutput = myInput.split('').sort().join('');
    alert("Demo Alert " + myOutput);
}