function ValidateEmail(inputText) {
    //   var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    // var mailformat = "^ ([a - zA - Z0 - 9 _\ - \.] + ) @([a - zA - Z0 - 9 _\ - \.] + )\.([a - zA - Z] { 2, 5 }) $";
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/

    //var mailformat = /^\w+([a-z0-9\.-])@([a-z0-9-]+).([a-z]{2,8})(.[a-z]{2,8})$/;
    if (inputText.value.match(mailformat)) {
        document.form1.text1.focus();
        return true;
    } else {
        alert("You have entered an invalid email address!");
        document.form1.text1.focus();
        return false;
    }
}